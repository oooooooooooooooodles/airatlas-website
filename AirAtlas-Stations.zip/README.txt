AirAtlas station metadata snapshot
Snapshot date: 2026-11-04
Records: 63079 (the importer may skip incomplete/duplicate records)
Source: https://de2.api.radio-browser.info/json/stations
Data source information: https://www.radio-browser.info/
The source dedicates its accumulated directory metadata to the public domain.
Directory metadata permission does not license audio, station logos or trademarks.
This archive contains metadata and links, not audio or embedded images.
Some stations may no longer work or may be subject to provider access restrictions.
Unzip in Files, then Settings > App Settings > Import Stations and select stations.json.
Confirming import replaces the imported directory on this device. Personal library data is retained.
Import separately on each device; this directory is not synced as a whole through iCloud.
